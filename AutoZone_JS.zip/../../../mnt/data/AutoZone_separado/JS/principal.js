// =====================================================
// AUTOZONE - PRINCIPAL
// =====================================================


document.addEventListener("DOMContentLoaded", function () {

    // =================================================
    // PRODUCTOS DE AUTOZONE
    // =================================================

    const productosIniciales = [

        {
            id: "bmw",
            codigo: "A001",
            marca: "BMW",
            modelo: "Serie 3",
            nombre: "BMW Serie 3",
            año: 2024,
            transmision: "Automático",
            combustible: "Gasolina",
            descripcion: "Sedán deportivo con diseño elegante y tecnología avanzada.",
            precio: 28990000,
            stock: 5,
            stockCritico: 2,
            categoria: "Sedán",
            imagen: "../img/auto1.jpg"
        },

        {
            id: "audi",
            codigo: "A002",
            marca: "AUDI",
            modelo: "A4",
            nombre: "Audi A4",
            año: 2024,
            transmision: "Automático",
            combustible: "Gasolina",
            descripcion: "Vehículo premium que combina comodidad, tecnología y rendimiento.",
            precio: 31490000,
            stock: 3,
            stockCritico: 2,
            categoria: "Sedán",
            imagen: "../img/auto2.jpg"
        },

        {
            id: "mercedes",
            codigo: "A003",
            marca: "MERCEDES-BENZ",
            modelo: "Clase C",
            nombre: "Mercedes-Benz Clase C",
            año: 2023,
            transmision: "Automático",
            combustible: "Gasolina",
            descripcion: "Sedán premium con diseño sofisticado y alto nivel de confort.",
            precio: 35990000,
            stock: 2,
            stockCritico: 1,
            categoria: "Sedán",
            imagen: "../img/auto3.jpg"
        },

        {
            id: "toyota",
            codigo: "A004",
            marca: "TOYOTA",
            modelo: "Corolla",
            nombre: "Toyota Corolla",
            año: 2024,
            transmision: "Automático",
            combustible: "Híbrido",
            descripcion: "Vehículo eficiente y confiable con tecnología híbrida.",
            precio: 21990000,
            stock: 6,
            stockCritico: 2,
            categoria: "Híbrido",
            imagen: "../img/auto4.jpg"
        }

    ];


    // Productos administrados por AUTOZONE.
    // Se mantienen guardados aunque se recargue la página.

    let productos =
        JSON.parse(
            localStorage.getItem("productosAUTOZONE")
        ) || productosIniciales;


    // Completar datos que pudieran faltar en productos
    // guardados de una versión anterior.

    productos = productos.map(function (producto) {

        const productoBase =
            productosIniciales.find(function (base) {
                return base.id === producto.id;
            });

        if (!productoBase) {
            return producto;
        }

        return {
            ...productoBase,
            ...producto
        };

    });


    localStorage.setItem(
        "productosAUTOZONE",
        JSON.stringify(productos)
    );
    // =================================================
// MOSTRAR PRODUCTOS
// =================================================

const listaProductos =
    document.getElementById("lista-productos");


function mostrarProductos() {

    if (!listaProductos) {
        return;
    }

    listaProductos.innerHTML = "";


    productos.forEach(function (producto) {

        const tarjeta =
            document.createElement("a");

        tarjeta.href = "#" + producto.id;

        tarjeta.classList.add(
            "tarjeta-auto"
        );


        tarjeta.innerHTML = `

            <div class="imagen-auto">

                <img
                    src="${producto.imagen}"
                    alt="${producto.marca} ${producto.modelo}"
                >

                <span class="etiqueta">
                    Disponible
                </span>

            </div>


            <div class="info-auto">

                <p class="marca-auto">
                    ${producto.marca}
                </p>

                <h3>
                    ${producto.modelo}
                </h3>


                <div class="detalles-auto">

                    <span>
                        ${producto.año}
                    </span>

                    <span>
                        ${producto.transmision}
                    </span>

                    <span>
                        ${producto.combustible}
                    </span>

                </div>


                <div class="precio-auto">

                    <span>
                        Desde
                    </span>

                    <strong>
                        ${formatearPrecio(producto.precio)}
                    </strong>

                </div>


                <div class="boton-auto">
                    Ver detalles
                </div>


                <div
                    class="boton-carrito"
                    data-vehiculo="${producto.marca} ${producto.modelo}"
                    data-precio="${producto.precio}"
                >
                    🛒 Agregar al carrito
                </div>

            </div>

        `;


        listaProductos.appendChild(tarjeta);

    });


    // Activamos nuevamente los botones
    // de agregar al carrito.

    const botonesCarrito =
        listaProductos.querySelectorAll(
            ".boton-carrito"
        );


    botonesCarrito.forEach(function (boton) {

        boton.addEventListener(
            "click",
            function (evento) {

                evento.preventDefault();

                evento.stopPropagation();


                const vehiculo =
                    boton.dataset.vehiculo;

                const precio =
                    Number(
                        boton.dataset.precio
                    );


                const auto = {
                    vehiculo: vehiculo,
                    precio: precio
                };


                carrito.push(auto);


                localStorage.setItem(
                    "carritoAUTOZONE",
                    JSON.stringify(carrito)
                );


                actualizarContadorCarrito();


                alert(
                    vehiculo +
                    " fue agregado al carrito."
                );

            }
        );

    });

}


// Ejecutamos la función

mostrarProductos();

    // =================================================
    // 1. CARRITO DE COMPRAS
    // =================================================

    // Recuperamos el carrito desde localStorage.
    // Si no existe, comenzamos con un arreglo vacío.
    let carrito =
        JSON.parse(
            localStorage.getItem("carritoAUTOZONE")
        ) || [];


    // Elementos del carrito
    const listaCarrito =
        document.getElementById("lista-carrito");

    const carritoVacio =
        document.getElementById("carrito-vacio");

    const totalCarrito =
        document.getElementById("total-carrito");

    const contadorCarrito =
        document.getElementById("contador-carrito");


    // =================================================
    // FORMATEAR PRECIOS
    // =================================================

    function formatearPrecio(precio) {

        return "$" + precio.toLocaleString("es-CL");

    }


    // =================================================
    // ACTUALIZAR CONTADOR
    // =================================================

    function actualizarContadorCarrito() {

        if (contadorCarrito) {

            contadorCarrito.textContent =
                carrito.length;

        }

    }


    // =================================================
    // MOSTRAR CARRITO
    // =================================================

    function mostrarCarrito() {

        // Si la sección del carrito no existe,
        // no hacemos nada.
        if (!listaCarrito) {
            return;
        }


        // Limpiamos la lista
        listaCarrito.innerHTML = "";


        // ---------------------------------------------
        // SI EL CARRITO ESTÁ VACÍO
        // ---------------------------------------------

        if (carrito.length === 0) {

            if (carritoVacio) {
                carritoVacio.style.display = "block";
            }

            listaCarrito.style.display = "none";


            if (totalCarrito) {
                totalCarrito.textContent = "$0";
            }

            return;
        }


        // ---------------------------------------------
        // SI HAY PRODUCTOS
        // ---------------------------------------------

        if (carritoVacio) {
            carritoVacio.style.display = "none";
        }

        listaCarrito.style.display = "flex";


        // Variable para calcular el total
        let total = 0;


        // Recorremos todos los vehículos
        carrito.forEach(function (auto, indice) {

            // Sumamos el precio
            total += auto.precio;


            // Creamos el elemento
            const item =
                document.createElement("div");

            item.classList.add(
                "item-carrito"
            );


            // Contenido del producto
            item.innerHTML = `

                <div class="info-item-carrito">

                    <strong>
                        ${auto.vehiculo}
                    </strong>

                    <span>
                        ${formatearPrecio(auto.precio)}
                    </span>

                </div>

                <button
                    type="button"
                    class="boton-eliminar-carrito"
                    data-indice="${indice}">
                    🗑️ Eliminar
                </button>

            `;


            // Agregamos el producto a la lista
            listaCarrito.appendChild(item);

        });


        // Mostramos el total
        if (totalCarrito) {

            totalCarrito.textContent =
                formatearPrecio(total);

        }


        // =================================================
        // BOTONES ELIMINAR
        // =================================================

        const botonesEliminar =
            document.querySelectorAll(
                ".boton-eliminar-carrito"
            );


        botonesEliminar.forEach(function (boton) {

            boton.addEventListener(
                "click",
                function () {

                    // Obtenemos el índice
                    const indice =
                        Number(
                            boton.dataset.indice
                        );


                    // Eliminamos el vehículo
                    carrito.splice(
                        indice,
                        1
                    );


                    // Guardamos nuevamente
                    localStorage.setItem(
                        "carritoAUTOZONE",
                        JSON.stringify(carrito)
                    );


                    // Actualizamos contador
                    actualizarContadorCarrito();


                    // Actualizamos carrito
                    mostrarCarrito();

                }
            );

        });

    }

    // Actualizamos el contador
    // al cargar la página.
    actualizarContadorCarrito();


    // Mostramos el carrito cuando cambia el hash.
    window.addEventListener(
        "hashchange",
        function () {

            if (
                window.location.hash ===
                "#carrito"
            ) {

                mostrarCarrito();

            }

        }
    );


    // Si la página se abre directamente con #carrito
    // (por ejemplo, desde Inicio), hashchange no se dispara.
    // Por eso lo mostramos también al cargar la página.
    if (window.location.hash === "#carrito") {

        mostrarCarrito();

    }


});
