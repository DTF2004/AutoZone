// =====================================================
// AUTOZONE - ADMIN
// =====================================================


document.addEventListener("DOMContentLoaded", function () {

    // =================================================
    // DATOS COMPARTIDOS DEL ADMINISTRADOR
    // =================================================
    // principal.js guarda los productos en localStorage, pero
    // sus variables están dentro de su propia función.
    // Por eso el administrador debe cargarlos nuevamente.
    let productos = JSON.parse(
        localStorage.getItem("productosAUTOZONE") || "[]"
    );

    function formatearPrecio(precio) {
        return Number(precio || 0).toLocaleString("es-CL", {
            style: "currency",
            currency: "CLP",
            maximumFractionDigits: 0
        });
    }

    // =================================================
    // 9. CRUD DE PRODUCTOS - ADMINISTRACIÓN
    // =================================================

    const botonNuevoProducto =
        document.getElementById("boton-nuevo-producto");

    const formularioProductoContenedor =
        document.getElementById("formulario-producto-admin");

    const formularioProductoAdmin =
        document.getElementById("form-producto-admin");

    const botonCerrarFormulario =
        document.getElementById("boton-cerrar-formulario-producto");

    const botonCancelarProducto =
        document.getElementById("boton-cancelar-producto");

    const tablaProductosAdmin =
        document.getElementById("tabla-productos-admin");


    // -------------------------------------------------
    // MOSTRAR PRODUCTOS EN EL ADMINISTRADOR
    // -------------------------------------------------

    function mostrarProductosAdmin() {

        if (!tablaProductosAdmin) {
            return;
        }

        tablaProductosAdmin.innerHTML = "";

        productos.forEach(function (producto) {

            const fila =
                document.createElement("div");

            fila.classList.add("admin-tabla-fila");

            fila.innerHTML = `

                <span>
                    ${producto.codigo || "SIN CÓDIGO"}
                </span>

                <strong>
                    ${producto.nombre}
                </strong>

                <span>
                    ${formatearPrecio(producto.precio)}
                </span>

                <span
                    class="${
                        producto.stock <= producto.stockCritico
                            ? "stock-critico"
                            : ""
                    }"
                >
                    ${producto.stock}
                </span>

                <div class="admin-acciones">

                    <button
                        type="button"
                        class="boton-editar-producto"
                        data-id="${producto.id}"
                    >
                        Editar
                    </button>

                    <button
                        type="button"
                        class="boton-eliminar-producto"
                        data-id="${producto.id}"
                    >
                        Eliminar
                    </button>

                </div>

            `;

            tablaProductosAdmin.appendChild(fila);

        });

        activarBotonesProductosAdmin();

        const cantidadProductos =
            document.getElementById("cantidad-productos");

        if (cantidadProductos) {
            cantidadProductos.textContent = productos.length;
        }
    }


    // -------------------------------------------------
    // ABRIR FORMULARIO PARA NUEVO PRODUCTO
    // -------------------------------------------------

    function abrirFormularioProducto() {

        if (!formularioProductoAdmin ||
            !formularioProductoContenedor) {
            return;
        }

        formularioProductoAdmin.reset();

        document.getElementById(
            "producto-editando"
        ).value = "";

        document.getElementById(
            "titulo-formulario-producto"
        ).textContent = "Nuevo producto";

        formularioProductoContenedor.classList.add("activo");
    }


    // -------------------------------------------------
    // CERRAR FORMULARIO
    // -------------------------------------------------

    function cerrarFormularioProducto() {

        if (!formularioProductoAdmin ||
            !formularioProductoContenedor) {
            return;
        }

        formularioProductoAdmin.reset();

        document.getElementById(
            "producto-editando"
        ).value = "";

        formularioProductoContenedor.classList.remove("activo");
    }


    // -------------------------------------------------
    // EDITAR PRODUCTO
    // -------------------------------------------------

    function editarProductoAdmin(id) {

        const producto =
            productos.find(function (item) {
                return item.id === id;
            });

        if (!producto) {
            return;
        }

        document.getElementById(
            "producto-editando"
        ).value = producto.id;

        document.getElementById(
            "admin-codigo"
        ).value = producto.codigo || "";

        document.getElementById(
            "admin-nombre"
        ).value = producto.nombre || "";

        document.getElementById(
            "admin-descripcion"
        ).value = producto.descripcion || "";

        document.getElementById(
            "admin-precio"
        ).value = producto.precio || 0;

        document.getElementById(
            "admin-stock"
        ).value = producto.stock || 0;

        document.getElementById(
            "admin-stock-critico"
        ).value = producto.stockCritico || 0;

        document.getElementById(
            "admin-categoria"
        ).value = producto.categoria || "";

        document.getElementById(
            "admin-imagen"
        ).value = producto.imagen || "";

        document.getElementById(
            "titulo-formulario-producto"
        ).textContent = "Editar producto";

        formularioProductoContenedor.classList.add("activo");

        formularioProductoContenedor.scrollIntoView({
            behavior: "smooth"
        });
    }


    // -------------------------------------------------
    // ELIMINAR PRODUCTO
    // -------------------------------------------------

    function eliminarProductoAdmin(id) {

        const producto =
            productos.find(function (item) {
                return item.id === id;
            });

        if (!producto) {
            return;
        }

        const confirmar =
            confirm(
                "¿Deseas eliminar " +
                producto.nombre +
                "?"
            );

        if (!confirmar) {
            return;
        }

        productos =
            productos.filter(function (item) {
                return item.id !== id;
            });

        localStorage.setItem(
            "productosAUTOZONE",
            JSON.stringify(productos)
        );

        mostrarProductos();
        mostrarProductosAdmin();

        alert(
            "Producto eliminado correctamente."
        );
    }


    // -------------------------------------------------
    // ACTIVAR BOTONES EDITAR / ELIMINAR
    // -------------------------------------------------

    function activarBotonesProductosAdmin() {

        const botonesEditar =
            document.querySelectorAll(
                ".boton-editar-producto"
            );

        botonesEditar.forEach(function (boton) {

            boton.addEventListener(
                "click",
                function () {

                    editarProductoAdmin(
                        boton.dataset.id
                    );

                }
            );

        });


        const botonesEliminar =
            document.querySelectorAll(
                ".boton-eliminar-producto"
            );

        botonesEliminar.forEach(function (boton) {

            boton.addEventListener(
                "click",
                function () {

                    eliminarProductoAdmin(
                        boton.dataset.id
                    );

                }
            );

        });
    }


    // -------------------------------------------------
    // GUARDAR PRODUCTO
    // -------------------------------------------------

    if (formularioProductoAdmin) {

        formularioProductoAdmin.addEventListener(
            "submit",
            function (evento) {

                evento.preventDefault();

                const codigo =
                    document.getElementById(
                        "admin-codigo"
                    ).value.trim();

                const nombre =
                    document.getElementById(
                        "admin-nombre"
                    ).value.trim();

                const descripcion =
                    document.getElementById(
                        "admin-descripcion"
                    ).value.trim();

                const precio =
                    Number(
                        document.getElementById(
                            "admin-precio"
                        ).value
                    );

                const stock =
                    Number(
                        document.getElementById(
                            "admin-stock"
                        ).value
                    );

                const stockCritico =
                    Number(
                        document.getElementById(
                            "admin-stock-critico"
                        ).value
                    );

                const categoria =
                    document.getElementById(
                        "admin-categoria"
                    ).value;

                const imagen =
                    document.getElementById(
                        "admin-imagen"
                    ).value.trim();


                // Validaciones

                if (
                    codigo === "" ||
                    nombre === "" ||
                    descripcion === "" ||
                    precio <= 0 ||
                    stock < 0 ||
                    stockCritico < 0 ||
                    categoria === "" ||
                    imagen === ""
                ) {

                    alert(
                        "Completa correctamente todos los campos."
                    );

                    return;
                }


                // Stock crítico no puede superar el stock.

                if (stockCritico > stock) {

                    alert(
                        "El stock crítico no puede ser mayor que el stock."
                    );

                    return;
                }


                const idEditando =
                    document.getElementById(
                        "producto-editando"
                    ).value;


                // =========================================
                // EDITAR PRODUCTO
                // =========================================

                if (idEditando !== "") {

                    const producto =
                        productos.find(function (item) {
                            return item.id === idEditando;
                        });

                    if (producto) {

                        producto.codigo = codigo;
                        producto.nombre = nombre;
                        producto.descripcion = descripcion;
                        producto.precio = precio;
                        producto.stock = stock;
                        producto.stockCritico = stockCritico;
                        producto.categoria = categoria;
                        producto.imagen = imagen;


                        // Actualizamos marca y modelo
                        // para mantener la tarjeta pública.

                        const partesNombre =
                            nombre.split(" ");

                        producto.marca =
                            partesNombre[0];

                        producto.modelo =
                            partesNombre
                                .slice(1)
                                .join(" ");


                        localStorage.setItem(
                            "productosAUTOZONE",
                            JSON.stringify(productos)
                        );


                        mostrarProductos();
                        mostrarProductosAdmin();
                        cerrarFormularioProducto();


                        alert(
                            "Producto actualizado correctamente."
                        );
                    }

                    return;
                }


                // =========================================
                // CREAR PRODUCTO
                // =========================================

                const partesNombre =
                    nombre.split(" ");


                const nuevoProducto = {

                    id:
                        "producto-" + Date.now(),

                    codigo:
                        codigo,

                    marca:
                        partesNombre[0],

                    modelo:
                        partesNombre
                            .slice(1)
                            .join(" "),

                    nombre:
                        nombre,

                    año:
                        new Date().getFullYear(),

                    transmision:
                        "Automático",

                    combustible:
                        "Gasolina",

                    descripcion:
                        descripcion,

                    precio:
                        precio,

                    stock:
                        stock,

                    stockCritico:
                        stockCritico,

                    categoria:
                        categoria,

                    imagen:
                        imagen
                };


                productos.push(
                    nuevoProducto
                );


                localStorage.setItem(
                    "productosAUTOZONE",
                    JSON.stringify(productos)
                );


                mostrarProductos();
                mostrarProductosAdmin();
                cerrarFormularioProducto();


                alert(
                    "Producto creado correctamente."
                );
            }
        );
    }


    // -------------------------------------------------
    // BOTÓN NUEVO PRODUCTO
    // -------------------------------------------------

    if (botonNuevoProducto) {

        botonNuevoProducto.addEventListener(
            "click",
            function () {

                abrirFormularioProducto();

            }
        );
    }


    // -------------------------------------------------
    // BOTONES CERRAR / CANCELAR
    // -------------------------------------------------

    if (botonCerrarFormulario) {

        botonCerrarFormulario.addEventListener(
            "click",
            function () {

                cerrarFormularioProducto();

            }
        );
    }


    if (botonCancelarProducto) {

        botonCancelarProducto.addEventListener(
            "click",
            function () {

                cerrarFormularioProducto();

            }
        );
    }


    // -------------------------------------------------
    // CARGAR TABLA AL ENTRAR
    // -------------------------------------------------

    mostrarProductosAdmin();

// =================================================
// 10. CRUD DE USUARIOS - ADMINISTRACIÓN
// =================================================


// =================================================
// USUARIOS INICIALES
// =================================================

// Creamos un usuario administrador inicial.
// Este usuario aparecerá cuando se abra
// por primera vez el mantenedor de usuarios.

const usuariosIniciales = [

    {
        id: "usuario-1",
        run: "12.345.678-9",
        nombre: "Administrador",
        apellidos: "AUTOZONE",
        correo: "admin@duoc.cl",
        contrasena: "123456",
        fechaNacimiento: "1990-01-01",
        tipoUsuario: "Admin",
        region: "Región Metropolitana",
        comuna: "Santiago",
        direccion: "Av. Principal 123"
    }

];


// =================================================
// CARGAR USUARIOS DESDE LOCALSTORAGE
// =================================================

// Intentamos recuperar los usuarios guardados.

// Si existen usuarios guardados,
// utilizamos esos.

// Si no existen,
// utilizamos los usuarios iniciales.

let usuarios =
    JSON.parse(
        localStorage.getItem(
            "usuariosAUTOZONE"
        )
    ) || usuariosIniciales;


// Guardamos los usuarios iniciales
// en localStorage.

localStorage.setItem(
    "usuariosAUTOZONE",
    JSON.stringify(usuarios)
);


// =================================================
// ELEMENTOS DEL ADMINISTRADOR
// =================================================

const tablaUsuariosAdmin =
    document.getElementById(
        "tabla-usuarios-admin"
    );


// Buscamos el botón "+ Nuevo usuario".

const botonNuevoUsuario =
    document.querySelector(
        "#admin-usuarios .boton-admin-principal"
    );


// Buscamos el contador de usuarios
// que aparece en el inicio del administrador.

const cantidadUsuarios =
    document.getElementById(
        "cantidad-usuarios"
    );


// =================================================
// MOSTRAR USUARIOS
// =================================================

function mostrarUsuariosAdmin() {

    // Si la tabla no existe,
    // terminamos la función.

    if (!tablaUsuariosAdmin) {
        return;
    }


    // Limpiamos la tabla antes de volver
    // a cargar los usuarios.

    tablaUsuariosAdmin.innerHTML = "";


    // Recorremos todos los usuarios.

    usuarios.forEach(function (usuario) {


        // Creamos una fila.

        const fila =
            document.createElement(
                "div"
            );


        fila.classList.add(
            "admin-tabla-fila"
        );


        // Creamos el contenido de la fila.

        fila.innerHTML = `

            <span>
                ${usuario.run}
            </span>


            <strong>
                ${usuario.nombre}
                ${usuario.apellidos}
            </strong>


            <span>
                ${usuario.correo}
            </span>


            <span
                class="${
                    usuario.tipoUsuario === "Admin"
                        ? "rol-admin"
                        : ""
                }"
            >
                ${usuario.tipoUsuario.toUpperCase()}
            </span>


            <div class="admin-acciones">

                <button
                    type="button"
                    class="boton-editar-usuario"
                    data-id="${usuario.id}"
                >
                    Editar
                </button>


                <button
                    type="button"
                    class="boton-eliminar-usuario"
                    data-id="${usuario.id}"
                >
                    Eliminar
                </button>

            </div>

        `;


        // Agregamos la fila a la tabla.

        tablaUsuariosAdmin.appendChild(
            fila
        );

    });


    // Actualizamos el contador
    // del panel de administración.

    if (cantidadUsuarios) {

        cantidadUsuarios.textContent =
            usuarios.length;

    }


    // Activamos los botones
    // de editar y eliminar.

    activarBotonesUsuarios();

}


// =================================================
// ACTIVAR BOTONES DE USUARIOS
// =================================================

function activarBotonesUsuarios() {


    // =============================================
    // BOTONES EDITAR
    // =============================================

    const botonesEditar =
        document.querySelectorAll(
            ".boton-editar-usuario"
        );


    botonesEditar.forEach(
        function (boton) {

            boton.addEventListener(
                "click",
                function () {

                    const id =
                        boton.dataset.id;


                    editarUsuario(
                        id
                    );

                }
            );

        }
    );


    // =============================================
    // BOTONES ELIMINAR
    // =============================================

    const botonesEliminar =
        document.querySelectorAll(
            ".boton-eliminar-usuario"
        );


    botonesEliminar.forEach(
        function (boton) {

            boton.addEventListener(
                "click",
                function () {

                    const id =
                        boton.dataset.id;


                    eliminarUsuario(
                        id
                    );

                }
            );

        }
    );

}


// =================================================
// EDITAR USUARIO
// =================================================

function editarUsuario(id) {

    const usuario = usuarios.find(function (item) {
        return item.id === id;
    });

    if (!usuario) {
        return;
    }

    const formularioUsuario = document.getElementById("formulario-usuario-admin");
    const formulario = document.getElementById("form-usuario-admin");
    const tituloFormulario = document.getElementById("titulo-formulario-usuario");

    if (!formularioUsuario || !formulario) {
        return;
    }

    document.getElementById("usuario-editando").value = usuario.id;
    document.getElementById("admin-run").value = usuario.run || "";
    document.getElementById("admin-nombre-usuario").value = usuario.nombre || "";
    document.getElementById("admin-apellidos-usuario").value = usuario.apellidos || "";
    document.getElementById("admin-correo-usuario").value = usuario.correo || "";
    document.getElementById("admin-fecha-nacimiento").value = usuario.fechaNacimiento || "";
    document.getElementById("admin-tipo-usuario").value = usuario.tipoUsuario || "Cliente";
    document.getElementById("admin-region").value = usuario.region || "";
    document.getElementById("admin-comuna").value = usuario.comuna || "";
    document.getElementById("admin-direccion").value = usuario.direccion || "";

    tituloFormulario.textContent = "Editar usuario";
    formularioUsuario.style.display = "block";
    formularioUsuario.scrollIntoView({ behavior: "smooth", block: "start" });
}


// =================================================
// ELIMINAR USUARIO
// =================================================

function eliminarUsuario(id) {


    // Buscamos el usuario.

    const usuario =
        usuarios.find(
            function (item) {

                return item.id === id;

            }
        );


    if (!usuario) {
        return;
    }


    // Pedimos confirmación.

    const confirmar =
        confirm(
            "¿Deseas eliminar al usuario " +
            usuario.nombre +
            " " +
            usuario.apellidos +
            "?"
        );


    if (!confirmar) {
        return;
    }


    // Eliminamos el usuario.

    usuarios =
        usuarios.filter(
            function (item) {

                return item.id !== id;

            }
        );


    // Guardamos los cambios.

    localStorage.setItem(
        "usuariosAUTOZONE",
        JSON.stringify(usuarios)
    );


    // Actualizamos la tabla.

    mostrarUsuariosAdmin();


    alert(
        "Usuario eliminado correctamente."
    );

}


// =================================================
// NUEVO / EDITAR USUARIO
// =================================================

if (botonNuevoUsuario) {

    botonNuevoUsuario.addEventListener("click", function () {

        const formularioUsuario = document.getElementById("formulario-usuario-admin");
        const tituloFormulario = document.getElementById("titulo-formulario-usuario");
        const formulario = document.getElementById("form-usuario-admin");
        const usuarioEditando = document.getElementById("usuario-editando");

        if (formulario) {
            formulario.reset();
        }

        if (usuarioEditando) {
            usuarioEditando.value = "";
        }

        if (tituloFormulario) {
            tituloFormulario.textContent = "Nuevo usuario";
        }

        if (formularioUsuario) {
            formularioUsuario.style.display = "block";
            formularioUsuario.scrollIntoView({ behavior: "smooth", block: "start" });
        }
    });
}


// Guardar nuevo usuario o cambios de un usuario existente.
const formularioUsuarioAdmin = document.getElementById("form-usuario-admin");

if (formularioUsuarioAdmin) {

    formularioUsuarioAdmin.addEventListener("submit", function (evento) {
        evento.preventDefault();

        const idEditando = document.getElementById("usuario-editando").value.trim();
        const run = document.getElementById("admin-run").value.trim();
        const nombre = document.getElementById("admin-nombre-usuario").value.trim();
        const apellidos = document.getElementById("admin-apellidos-usuario").value.trim();
        const correo = document.getElementById("admin-correo-usuario").value.trim();
        const fechaNacimiento = document.getElementById("admin-fecha-nacimiento").value;
        const tipoUsuario = document.getElementById("admin-tipo-usuario").value;
        const region = document.getElementById("admin-region").value;
        const comuna = document.getElementById("admin-comuna").value;
        const direccion = document.getElementById("admin-direccion").value.trim();

        if (!nombre || !apellidos || !correo || !tipoUsuario) {
            alert("Completa nombre, apellidos, correo y tipo de usuario.");
            return;
        }

        const correoValido = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo);
        if (!correoValido) {
            alert("Ingresa un correo electrónico válido.");
            return;
        }

        const correoDuplicado = usuarios.some(function (usuario) {
            return usuario.correo.toLowerCase() === correo.toLowerCase() && usuario.id !== idEditando;
        });

        if (correoDuplicado) {
            alert("Ya existe un usuario con ese correo.");
            return;
        }

        if (idEditando) {

            const usuario = usuarios.find(function (item) {
                return item.id === idEditando;
            });

            if (!usuario) {
                alert("No se encontró el usuario que deseas modificar.");
                return;
            }

            usuario.run = run;
            usuario.nombre = nombre;
            usuario.apellidos = apellidos;
            usuario.correo = correo;
            usuario.fechaNacimiento = fechaNacimiento;
            usuario.tipoUsuario = tipoUsuario;
            usuario.region = region;
            usuario.comuna = comuna;
            usuario.direccion = direccion;

            localStorage.setItem("usuariosAUTOZONE", JSON.stringify(usuarios));
            mostrarUsuariosAdmin();
            formularioUsuarioAdmin.reset();
            document.getElementById("usuario-editando").value = "";
            document.getElementById("formulario-usuario-admin").style.display = "none";

            alert("Usuario actualizado correctamente.");
            return;
        }

        const nuevoUsuario = {
            id: "usuario-" + Date.now(),
            run: run,
            nombre: nombre,
            apellidos: apellidos,
            correo: correo,
            contrasena: "123456",
            fechaNacimiento: fechaNacimiento,
            tipoUsuario: tipoUsuario,
            region: region,
            comuna: comuna,
            direccion: direccion
        };

        usuarios.push(nuevoUsuario);
        localStorage.setItem("usuariosAUTOZONE", JSON.stringify(usuarios));
        mostrarUsuariosAdmin();

        formularioUsuarioAdmin.reset();
        document.getElementById("usuario-editando").value = "";
        document.getElementById("formulario-usuario-admin").style.display = "none";

        alert("Usuario creado correctamente.\nContraseña inicial: 123456");
    });
}


const botonCancelarUsuario = document.getElementById("boton-cancelar-usuario");

if (botonCancelarUsuario) {
    botonCancelarUsuario.addEventListener("click", function () {
        const formulario = document.getElementById("form-usuario-admin");
        const contenedor = document.getElementById("formulario-usuario-admin");
        const usuarioEditando = document.getElementById("usuario-editando");

        if (formulario) {
            formulario.reset();
        }
        if (usuarioEditando) {
            usuarioEditando.value = "";
        }
        if (contenedor) {
            contenedor.style.display = "none";
        }
    });
}


// Cargar la tabla de usuarios al entrar al panel.
mostrarUsuariosAdmin();

});
