// =====================================================
// AUTOZONE - LOGIN
// =====================================================


document.addEventListener("DOMContentLoaded", function () {

    // En login.html se muestra automáticamente el formulario.
    // En index.html NO se cambia la URL: el menú abre el login como ventana modal.
    const esPaginaLogin =
        window.location.pathname.endsWith("/login.html") ||
        window.location.pathname.endsWith("\\login.html");

    if (esPaginaLogin && !window.location.hash) {
        window.location.hash = "login";
    }

    // =================================================
    // MODAL DE LOGIN EN LA PÁGINA DE INICIO
    // =================================================
    const botonLoginInicio = document.getElementById("abrir-login-inicio");
    const modalLogin = document.getElementById("loginModal");

    if (botonLoginInicio && modalLogin) {

        botonLoginInicio.addEventListener("click", function (evento) {
            evento.preventDefault();

            // Usamos Bootstrap cuando está disponible.
            if (window.bootstrap && bootstrap.Modal) {
                const instancia = bootstrap.Modal.getOrCreateInstance(modalLogin);
                instancia.show();
                return;
            }

            // Respaldo: si Bootstrap todavía no cargó,
            // mostramos igualmente la ventana sin cambiar de página.
            modalLogin.classList.add("show");
            modalLogin.style.display = "block";
            modalLogin.setAttribute("aria-hidden", "false");
            document.body.classList.add("modal-open");
        });

        // Cerrar la ventana con la X sin abandonar Inicio.
        const botonCerrarLogin = modalLogin.querySelector("[data-bs-dismiss='modal']");

        if (botonCerrarLogin) {
            botonCerrarLogin.addEventListener("click", function (evento) {
                evento.preventDefault();

                if (window.bootstrap && bootstrap.Modal) {
                    const instancia = bootstrap.Modal.getOrCreateInstance(modalLogin);
                    instancia.hide();
                } else {
                    modalLogin.classList.remove("show");
                    modalLogin.style.display = "none";
                    modalLogin.setAttribute("aria-hidden", "true");
                    document.body.classList.remove("modal-open");
                }
            });
        }

        modalLogin.addEventListener("hidden.bs.modal", function () {
            history.replaceState(null, "", window.location.pathname + window.location.search);
        });
    }

    // =================================================
    // 3. INICIO DE SESIÓN
    // =================================================

    const formularioLogin =
        document.querySelector("#loginModal form") ||
        document.querySelector("#login form");

    if (formularioLogin) {

        formularioLogin.addEventListener("submit", function (evento) {

            evento.preventDefault();

            const correo =
                document.getElementById("correo").value.trim();

            const contrasena =
                document.getElementById("contrasena").value;

            // =================================================
            // USUARIO ADMINISTRADOR INICIAL
            // =================================================
            // Se crea aquí también para que el administrador pueda
            // iniciar sesión ANTES de haber visitado admin.html.
            const administradorInicial = {
                id: "usuario-1",
                run: "12.345.678-9",
                nombre: "Administrador",
                apellidos: "AUTOZONE",
                correo: "admin@duoc.cl",
                contrasena: "123456",
                fechaNacimiento: "1990-01-01",
                tipoUsuario: "Admin",
                region: "Región Metropolitana",
                comuna: "Santiago",
                direccion: "Av. Principal 123"
            };

            let usuarios = [];

            try {
                usuarios = JSON.parse(
                    localStorage.getItem("usuariosAUTOZONE") || "[]"
                );
            } catch (error) {
                usuarios = [];
            }

            // Si el administrador no existe, lo agregamos.
            const existeAdmin = usuarios.some(function (usuario) {
                return usuario.correo &&
                       usuario.correo.toLowerCase() === "admin@duoc.cl";
            });

            if (!existeAdmin) {
                usuarios.push(administradorInicial);
                localStorage.setItem(
                    "usuariosAUTOZONE",
                    JSON.stringify(usuarios)
                );
            }

            // =================================================
            // BUSCAR USUARIO
            // =================================================
            let usuario = usuarios.find(function (usuarioActual) {
                return usuarioActual.correo &&
                    usuarioActual.correo.toLowerCase() === correo.toLowerCase() &&
                    usuarioActual.contrasena === contrasena;
            });

            // Compatibilidad con cuentas antiguas creadas desde registro.html.
            if (!usuario) {
                try {
                    const usuarioAntiguo = JSON.parse(
                        localStorage.getItem("usuarioAUTOZONE") || "null"
                    );

                    if (
                        usuarioAntiguo &&
                        usuarioAntiguo.correo &&
                        usuarioAntiguo.correo.toLowerCase() === correo.toLowerCase() &&
                        usuarioAntiguo.contrasena === contrasena
                    ) {
                        usuario = {
                            id: "usuario-" + Date.now(),
                            run: usuarioAntiguo.run || "",
                            nombre: usuarioAntiguo.nombre || "Usuario",
                            apellidos: usuarioAntiguo.apellidos || "",
                            correo: usuarioAntiguo.correo,
                            contrasena: usuarioAntiguo.contrasena,
                            fechaNacimiento: usuarioAntiguo.fechaNacimiento || "",
                            tipoUsuario: usuarioAntiguo.tipoUsuario || "Cliente",
                            region: usuarioAntiguo.region || "",
                            comuna: usuarioAntiguo.comuna || "",
                            direccion: usuarioAntiguo.direccion || ""
                        };

                        usuarios.push(usuario);
                        localStorage.setItem(
                            "usuariosAUTOZONE",
                            JSON.stringify(usuarios)
                        );
                    }
                } catch (error) {
                    // Si los datos antiguos están dañados,
                    // simplemente se continúa con el mensaje de error.
                }
            }

            // =================================================
            // CREDENCIALES INCORRECTAS
            // =================================================
            if (!usuario) {
                alert("Correo o contraseña incorrectos.");
                return;
            }

            // =================================================
            // GUARDAR SESIÓN ACTIVA
            // =================================================
            localStorage.setItem(
                "usuarioActivoAUTOZONE",
                JSON.stringify(usuario)
            );

            alert(
                "¡Bienvenido a AUTOZONE, " +
                usuario.nombre +
                "!"
            );

            // =================================================
            // REDIRECCIÓN SEGÚN EL ROL
            // =================================================
            if (usuario.tipoUsuario === "Admin") {
                window.location.href = "html/admin.html";
                return;
            }

            // Clientes permanecen en Inicio cuando el login se abre
            // desde el modal del Inicio.
            if (document.getElementById("loginModal")) {
                if (window.bootstrap && bootstrap.Modal) {
                    const instancia = bootstrap.Modal.getOrCreateInstance(
                        document.getElementById("loginModal")
                    );
                    instancia.hide();
                } else {
                    const modal = document.getElementById("loginModal");
                    modal.classList.remove("show");
                    modal.style.display = "none";
                    modal.setAttribute("aria-hidden", "true");
                    document.body.classList.remove("modal-open");
                }
                return;
            }

            window.location.href = "../index.html";
        });
    }




});
