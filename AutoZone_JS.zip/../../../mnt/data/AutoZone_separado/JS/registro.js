// =====================================================
// AUTOZONE - REGISTRO
// =====================================================


document.addEventListener("DOMContentLoaded", function () {

    // =================================================
    // VALIDACIONES EN TIEMPO REAL - REGISTRO
    // =================================================

    const nombreRegistro =
        document.getElementById("nombre-registro");

    const correoRegistro =
        document.getElementById("correo-registro");

    const telefonoRegistro =
        document.getElementById("telefono-registro");

    const contrasenaRegistro =
        document.getElementById("contrasena-registro");

    const confirmarRegistro =
        document.getElementById("confirmar-registro");


    // -------------------------------------------------
    // FUNCIÓN PARA MOSTRAR MENSAJE
    // -------------------------------------------------

    function mostrarMensaje(campo, mensaje, correcto) {

        // Buscamos si ya existe un mensaje
        let mensajeElemento =
            campo.parentElement.querySelector(
                ".mensaje-validacion"
            );


        // Si no existe, lo creamos
        if (!mensajeElemento) {

            mensajeElemento =
                document.createElement("span");

            mensajeElemento.classList.add(
                "mensaje-validacion"
            );

            campo.parentElement.appendChild(
                mensajeElemento
            );

        }


        // Escribimos el mensaje
        mensajeElemento.textContent = mensaje;


        // Cambiamos el estilo
        if (correcto) {

            campo.classList.remove(
                "campo-error"
            );

            campo.classList.add(
                "campo-correcto"
            );

            mensajeElemento.className =
                "mensaje-validacion mensaje-correcto";

        } else {

            campo.classList.remove(
                "campo-correcto"
            );

            campo.classList.add(
                "campo-error"
            );

            mensajeElemento.className =
                "mensaje-validacion mensaje-error";

        }

    }


    // -------------------------------------------------
    // VALIDAR NOMBRE
    // -------------------------------------------------

    if (nombreRegistro) {

        nombreRegistro.addEventListener(
            "input",
            function () {

                const nombre =
                    nombreRegistro.value.trim();


                if (nombre.length < 3) {

                    mostrarMensaje(
                        nombreRegistro,
                        "El nombre debe tener al menos 3 caracteres.",
                        false
                    );

                } else {

                    mostrarMensaje(
                        nombreRegistro,
                        "✓ Nombre válido.",
                        true
                    );

                }

            }
        );

    }


    // -------------------------------------------------
    // VALIDAR CORREO
    // -------------------------------------------------

    if (correoRegistro) {

        correoRegistro.addEventListener(
            "input",
            function () {

                const correo =
                    correoRegistro.value.trim();


                const formatoCorreo =
                    /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


                if (!formatoCorreo.test(correo)) {

                    mostrarMensaje(
                        correoRegistro,
                        "Ingresa un correo válido. Ejemplo: nombre@correo.cl",
                        false
                    );

                } else {

                    mostrarMensaje(
                        correoRegistro,
                        "✓ Correo válido.",
                        true
                    );

                }

            }
        );

    }


    // -------------------------------------------------
    // VALIDAR TELÉFONO
    // -------------------------------------------------

    if (telefonoRegistro) {

        telefonoRegistro.addEventListener(
            "input",
            function () {

                const telefono =
                    telefonoRegistro.value.trim();


                const soloNumeros =
                    /^[0-9]+$/;


                if (
                    !soloNumeros.test(telefono) ||
                    telefono.length < 8
                ) {

                    mostrarMensaje(
                        telefonoRegistro,
                        "Ingresa un teléfono válido de al menos 8 números.",
                        false
                    );

                } else {

                    mostrarMensaje(
                        telefonoRegistro,
                        "✓ Teléfono válido.",
                        true
                    );

                }

            }
        );

    }


    // -------------------------------------------------
    // VALIDAR CONTRASEÑA
    // -------------------------------------------------

    if (contrasenaRegistro) {

        contrasenaRegistro.addEventListener(
            "input",
            function () {

                const contrasena =
                    contrasenaRegistro.value;


                if (contrasena.length < 6) {

                    mostrarMensaje(
                        contrasenaRegistro,
                        "La contraseña debe tener al menos 6 caracteres.",
                        false
                    );

                } else {

                    mostrarMensaje(
                        contrasenaRegistro,
                        "✓ Contraseña válida.",
                        true
                    );

                }


                // También comprobamos
                // la confirmación
                if (
                    confirmarRegistro &&
                    confirmarRegistro.value.length > 0
                ) {

                    validarConfirmacion();

                }

            }
        );

    }


    // -------------------------------------------------
    // VALIDAR CONFIRMACIÓN
    // -------------------------------------------------

    function validarConfirmacion() {

        if (!confirmarRegistro) {
            return false;
        }


        if (
            confirmarRegistro.value !==
            contrasenaRegistro.value
        ) {

            mostrarMensaje(
                confirmarRegistro,
                "Las contraseñas no coinciden.",
                false
            );

            return false;

        }


        mostrarMensaje(
            confirmarRegistro,
            "✓ Las contraseñas coinciden.",
            true
        );

        return true;

    }


    if (confirmarRegistro) {

        confirmarRegistro.addEventListener(
            "input",
            validarConfirmacion
        );

    }
// =================================================
// 2. REGISTRO DE USUARIO
// =================================================

const formularioRegistro =
    document.querySelector(
        "#registro form"
    );


if (formularioRegistro) {

    formularioRegistro.addEventListener(
        "submit",
        function (evento) {

            // Evitamos que el formulario
            // se envíe automáticamente.
            evento.preventDefault();


            // =============================================
            // OBTENER LOS CAMPOS
            // =============================================

            const nombre =
                document.getElementById(
                    "nombre-registro"
                );

            const correo =
                document.getElementById(
                    "correo-registro"
                );

            const telefono =
                document.getElementById(
                    "telefono-registro"
                );

            const contrasena =
                document.getElementById(
                    "contrasena-registro"
                );

            const confirmar =
                document.getElementById(
                    "confirmar-registro"
                );


            // =============================================
            // OBTENER LOS VALORES
            // =============================================

            const nombreValor =
                nombre.value.trim();

            const correoValor =
                correo.value.trim();

            const telefonoValor =
                telefono.value.trim();

            const contrasenaValor =
                contrasena.value;

            const confirmarValor =
                confirmar.value;


            // =============================================
            // VARIABLES DE VALIDACIÓN
            // =============================================

            let formularioValido = true;


            // =============================================
            // VALIDAR NOMBRE
            // =============================================

            if (
                nombreValor.length < 3
            ) {

                mostrarMensaje(
                    nombre,
                    "El nombre debe tener al menos 3 caracteres.",
                    false
                );

                formularioValido = false;

            } else {

                mostrarMensaje(
                    nombre,
                    "✓ Nombre válido.",
                    true
                );

            }


            // =============================================
            // VALIDAR CORREO
            // =============================================

            const formatoCorreo =
                /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


            if (
                !formatoCorreo.test(
                    correoValor
                )
            ) {

                mostrarMensaje(
                    correo,
                    "Ingresa un correo válido. Ejemplo: nombre@correo.cl",
                    false
                );

                formularioValido = false;

            } else {

                mostrarMensaje(
                    correo,
                    "✓ Correo válido.",
                    true
                );

            }


            // =============================================
            // VALIDAR TELÉFONO
            // =============================================

            const soloNumeros =
                /^[0-9]+$/;


            if (
                !soloNumeros.test(
                    telefonoValor
                ) ||
                telefonoValor.length < 8
            ) {

                mostrarMensaje(
                    telefono,
                    "Ingresa un teléfono válido de al menos 8 números.",
                    false
                );

                formularioValido = false;

            } else {

                mostrarMensaje(
                    telefono,
                    "✓ Teléfono válido.",
                    true
                );

            }


            // =============================================
            // VALIDAR CONTRASEÑA
            // =============================================

            if (
                contrasenaValor.length < 6
            ) {

                mostrarMensaje(
                    contrasena,
                    "La contraseña debe tener al menos 6 caracteres.",
                    false
                );

                formularioValido = false;

            } else {

                mostrarMensaje(
                    contrasena,
                    "✓ Contraseña válida.",
                    true
                );

            }


            // =============================================
            // VALIDAR CONFIRMACIÓN
            // =============================================

            if (
                confirmarValor !==
                contrasenaValor
            ) {

                mostrarMensaje(
                    confirmar,
                    "Las contraseñas no coinciden.",
                    false
                );

                formularioValido = false;

            } else {

                mostrarMensaje(
                    confirmar,
                    "✓ Las contraseñas coinciden.",
                    true
                );

            }


            // =============================================
            // SI HAY ERRORES, NO CONTINUAMOS
            // =============================================

            if (!formularioValido) {

                alert(
                    "Por favor, corrige los errores antes de crear tu cuenta."
                );

                return;

            }


            // =============================================
            // CREAR OBJETO DEL USUARIO
            // =============================================

            const usuario = {

                nombre: nombreValor,

                correo: correoValor,

                telefono: telefonoValor,

                contrasena: contrasenaValor

            };


            // =============================================
            // GUARDAR USUARIO
            // =============================================

            localStorage.setItem(
                "usuarioAUTOZONE",
                JSON.stringify(usuario)
            );


            // =============================================
            // MENSAJE DE ÉXITO
            // =============================================

            alert(
                "¡Cuenta creada correctamente!"
            );


            // =============================================
            // IR AL LOGIN
            // =============================================

            window.location.href =
                "login.html";

        }
    );

}


});
