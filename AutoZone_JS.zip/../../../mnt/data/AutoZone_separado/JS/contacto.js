// =====================================================
// AUTOZONE - CONTACTO
// =====================================================


document.addEventListener("DOMContentLoaded", function () {

    // -------------------------------------------------

    function mostrarMensaje(campo, mensaje, correcto) {

        // Buscamos si ya existe un mensaje
        let mensajeElemento =
            campo.parentElement.querySelector(
                ".mensaje-validacion"
            );


        // Si no existe, lo creamos
        if (!mensajeElemento) {

            mensajeElemento =
                document.createElement("span");

            mensajeElemento.classList.add(
                "mensaje-validacion"
            );

            campo.parentElement.appendChild(
                mensajeElemento
            );

        }


        // Escribimos el mensaje
        mensajeElemento.textContent = mensaje;


        // Cambiamos el estilo
        if (correcto) {

            campo.classList.remove(
                "campo-error"
            );

            campo.classList.add(
                "campo-correcto"
            );

            mensajeElemento.className =
                "mensaje-validacion mensaje-correcto";

        } else {

            campo.classList.remove(
                "campo-correcto"
            );

            campo.classList.add(
                "campo-error"
            );

            mensajeElemento.className =
                "mensaje-validacion mensaje-error";

        }

    }



    // =================================================
// 6. FORMULARIO DE CONTACTO
// =================================================

const formularioContacto =
    document.querySelector(
        "#contacto form"
    );


if (formularioContacto) {

    const nombreContacto =
        document.getElementById("nombre");

    const correoContacto =
        document.getElementById("email");

    const asuntoContacto =
        document.getElementById("asunto");

    const mensajeContacto =
        document.getElementById("mensaje");


    // =============================================
    // VALIDAR NOMBRE
    // =============================================

    if (nombreContacto) {

        nombreContacto.addEventListener(
            "input",
            function () {

                const valor =
                    nombreContacto.value.trim();


                if (valor.length < 3) {

                    mostrarMensaje(
                        nombreContacto,
                        "El nombre debe tener al menos 3 caracteres.",
                        false
                    );

                } else {

                    mostrarMensaje(
                        nombreContacto,
                        "✓ Nombre válido.",
                        true
                    );

                }

            }
        );

    }


    // =============================================
    // VALIDAR CORREO
    // =============================================

    if (correoContacto) {

        correoContacto.addEventListener(
            "input",
            function () {

                const valor =
                    correoContacto.value.trim();


                const formatoCorreo =
                    /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


                if (
                    !formatoCorreo.test(valor)
                ) {

                    mostrarMensaje(
                        correoContacto,
                        "Ingresa un correo electrónico válido.",
                        false
                    );

                } else {

                    mostrarMensaje(
                        correoContacto,
                        "✓ Correo válido.",
                        true
                    );

                }

            }
        );

    }


    // =============================================
    // VALIDAR ASUNTO
    // =============================================

    if (asuntoContacto) {

        asuntoContacto.addEventListener(
            "input",
            function () {

                const valor =
                    asuntoContacto.value.trim();


                if (valor.length < 3) {

                    mostrarMensaje(
                        asuntoContacto,
                        "El asunto debe tener al menos 3 caracteres.",
                        false
                    );

                } else {

                    mostrarMensaje(
                        asuntoContacto,
                        "✓ Asunto válido.",
                        true
                    );

                }

            }
        );

    }


    // =============================================
    // VALIDAR MENSAJE
    // =============================================

    if (mensajeContacto) {

        mensajeContacto.addEventListener(
            "input",
            function () {

                const valor =
                    mensajeContacto.value.trim();


                if (valor.length < 10) {

                    mostrarMensaje(
                        mensajeContacto,
                        "El mensaje debe tener al menos 10 caracteres.",
                        false
                    );

                } else {

                    mostrarMensaje(
                        mensajeContacto,
                        "✓ Mensaje válido.",
                        true
                    );

                }

            }
        );

    }


    // =============================================
    // VALIDACIÓN AL ENVIAR
    // =============================================

    formularioContacto.addEventListener(
        "submit",
        function (evento) {

            evento.preventDefault();


            let formularioValido = true;


            // -----------------------------------------
            // NOMBRE
            // -----------------------------------------

            const nombre =
                nombreContacto.value.trim();


            if (nombre.length < 3) {

                mostrarMensaje(
                    nombreContacto,
                    "El nombre debe tener al menos 3 caracteres.",
                    false
                );

                formularioValido = false;

            }


            // -----------------------------------------
            // CORREO
            // -----------------------------------------

            const correo =
                correoContacto.value.trim();


            const formatoCorreo =
                /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


            if (
                !formatoCorreo.test(correo)
            ) {

                mostrarMensaje(
                    correoContacto,
                    "Ingresa un correo electrónico válido.",
                    false
                );

                formularioValido = false;

            }


            // -----------------------------------------
            // ASUNTO
            // -----------------------------------------

            const asunto =
                asuntoContacto.value.trim();


            if (asunto.length < 3) {

                mostrarMensaje(
                    asuntoContacto,
                    "El asunto debe tener al menos 3 caracteres.",
                    false
                );

                formularioValido = false;

            }


            // -----------------------------------------
            // MENSAJE
            // -----------------------------------------

            const mensaje =
                mensajeContacto.value.trim();


            if (mensaje.length < 10) {

                mostrarMensaje(
                    mensajeContacto,
                    "El mensaje debe tener al menos 10 caracteres.",
                    false
                );

                formularioValido = false;

            }


            // -----------------------------------------
            // SI HAY ERRORES
            // -----------------------------------------

            if (!formularioValido) {

                alert(
                    "Por favor, corrige los errores antes de enviar el mensaje."
                );

                return;

            }


            // -----------------------------------------
            // MOSTRAR EN CONSOLA
            // -----------------------------------------

            console.log(
                "================================="
            );

            console.log(
                "MENSAJE DE CONTACTO"
            );

            console.log(
                "Nombre:",
                nombre
            );

            console.log(
                "Correo:",
                correo
            );

            console.log(
                "Asunto:",
                asunto
            );

            console.log(
                "Mensaje:",
                mensaje
            );

            console.log(
                "================================="
            );


            // -----------------------------------------
            // LIMPIAR FORMULARIO
            // -----------------------------------------

            formularioContacto.reset();


            // -----------------------------------------
            // CONFIRMACIÓN
            // -----------------------------------------

            alert(
                "¡Mensaje enviado correctamente!\n\n" +
                "Gracias por contactarte con AUTOZONE."
            );


            // Volver a contacto
            window.location.hash =
                "contacto";

        }
    );

}




});
