// =====================================================
// AUTOZONE - VEHICULOS
// =====================================================


document.addEventListener("DOMContentLoaded", function () {

    let carrito =
        JSON.parse(
            localStorage.getItem("carritoAUTOZONE")
        ) || [];


    // -------------------------------------------------

    function mostrarMensaje(campo, mensaje, correcto) {

        // Buscamos si ya existe un mensaje
        let mensajeElemento =
            campo.parentElement.querySelector(
                ".mensaje-validacion"
            );


        // Si no existe, lo creamos
        if (!mensajeElemento) {

            mensajeElemento =
                document.createElement("span");

            mensajeElemento.classList.add(
                "mensaje-validacion"
            );

            campo.parentElement.appendChild(
                mensajeElemento
            );

        }


        // Escribimos el mensaje
        mensajeElemento.textContent = mensaje;


        // Cambiamos el estilo
        if (correcto) {

            campo.classList.remove(
                "campo-error"
            );

            campo.classList.add(
                "campo-correcto"
            );

            mensajeElemento.className =
                "mensaje-validacion mensaje-correcto";

        } else {

            campo.classList.remove(
                "campo-correcto"
            );

            campo.classList.add(
                "campo-error"
            );

            mensajeElemento.className =
                "mensaje-validacion mensaje-error";

        }

    }



    // =================================================
    // 4. SOLICITUD DE INFORMACIÓN
    // =================================================

    const formulariosConsulta =
        document.querySelectorAll(
            ".consulta form"
        );


    formulariosConsulta.forEach(
        function (formulario) {

            formulario.addEventListener(
                "submit",
                function (evento) {

                    evento.preventDefault();


                    // Encontrar la consulta
                    const consulta =
                        formulario.closest(
                            ".consulta"
                        );


                    // Vehículo
                    const vehiculo =
                        consulta.querySelector(
                            ".auto-consulta strong"
                        ).textContent;


                    // Datos
                    const nombre =
                        formulario.querySelector(
                            'input[id^="nombre-"]'
                        ).value;

                    const correo =
                        formulario.querySelector(
                            'input[id^="correo-"]'
                        ).value;

                    const telefono =
                        formulario.querySelector(
                            'input[id^="telefono-"]'
                        ).value;

                    const mensaje =
                        formulario.querySelector(
                            'textarea[id^="mensaje-"]'
                        ).value;


                    // Mostrar en consola
                    console.log(
                        "================================="
                    );

                    console.log(
                        "SOLICITUD DE INFORMACIÓN"
                    );

                    console.log(
                        "Vehículo:",
                        vehiculo
                    );

                    console.log(
                        "Nombre:",
                        nombre
                    );

                    console.log(
                        "Correo:",
                        correo
                    );

                    console.log(
                        "Teléfono:",
                        telefono
                    );

                    console.log(
                        "Mensaje:",
                        mensaje
                    );

                    console.log(
                        "================================="
                    );


                    // Limpiar formulario
                    formulario.reset();


                    // Confirmación
                    alert(
                        "¡Solicitud enviada correctamente!\n\n"
                        + "Vehículo: "
                        + vehiculo
                    );


                    // Volver a vehículos
                    window.location.hash =
                        "vehiculos";

                }

            );

        }
    );
// =================================================
// 5. FORMULARIOS DE COMPRA
// =================================================

const formulariosCompra =
    document.querySelectorAll(".compra form");


formulariosCompra.forEach(function (formulario) {

    // =============================================
    // CAMPOS DEL FORMULARIO
    // =============================================

    const nombre =
        formulario.querySelector(
            'input[id^="nombre-compra-"]'
        );

    const correo =
        formulario.querySelector(
            'input[id^="correo-compra-"]'
        );

    const telefono =
        formulario.querySelector(
            'input[id^="telefono-compra-"]'
        );

    const pago =
        formulario.querySelector(
            'select[id^="pago-"]'
        );


    // Si por alguna razón falta un campo,
    // no detenemos todo el JavaScript.
    if (
        !nombre ||
        !correo ||
        !telefono ||
        !pago
    ) {
        return;
    }


    // =============================================
    // VALIDACIÓN DEL NOMBRE
    // =============================================

    nombre.addEventListener(
        "input",
        function () {

            const valor =
                nombre.value.trim();

            if (valor.length < 3) {

                mostrarMensaje(
                    nombre,
                    "El nombre debe tener al menos 3 caracteres.",
                    false
                );

            } else {

                mostrarMensaje(
                    nombre,
                    "✓ Nombre válido.",
                    true
                );

            }

        }
    );


    // =============================================
    // VALIDACIÓN DEL CORREO
    // =============================================

    correo.addEventListener(
        "input",
        function () {

            const valor =
                correo.value.trim();

            const formatoCorreo =
                /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


            if (!formatoCorreo.test(valor)) {

                mostrarMensaje(
                    correo,
                    "Ingresa un correo electrónico válido.",
                    false
                );

            } else {

                mostrarMensaje(
                    correo,
                    "✓ Correo válido.",
                    true
                );

            }

        }
    );


    // =============================================
    // VALIDACIÓN DEL TELÉFONO
    // =============================================

    telefono.addEventListener(
        "input",
        function () {

            const valor =
                telefono.value.trim();


            if (
                !/^[0-9]+$/.test(valor) ||
                valor.length < 8
            ) {

                mostrarMensaje(
                    telefono,
                    "Ingresa un teléfono válido de al menos 8 dígitos.",
                    false
                );

            } else {

                mostrarMensaje(
                    telefono,
                    "✓ Teléfono válido.",
                    true
                );

            }

        }
    );


    // =============================================
    // VALIDACIÓN FORMA DE PAGO
    // =============================================

    pago.addEventListener(
        "change",
        function () {

            if (pago.value === "") {

                mostrarMensaje(
                    pago,
                    "Selecciona una forma de pago.",
                    false
                );

            } else {

                mostrarMensaje(
                    pago,
                    "✓ Forma de pago seleccionada.",
                    true
                );

            }

        }
    );


    // =============================================
    // ENVÍO DEL FORMULARIO
    // =============================================

    formulario.addEventListener(
        "submit",
        function (evento) {

            evento.preventDefault();


            let formularioValido = true;


            // =====================================
            // OBTENER VALORES
            // =====================================

            const valorNombre =
                nombre.value.trim();

            const valorCorreo =
                correo.value.trim();

            const valorTelefono =
                telefono.value.trim();


            // =====================================
            // VALIDAR NOMBRE
            // =====================================

            if (
                valorNombre.length < 3
            ) {

                mostrarMensaje(
                    nombre,
                    "El nombre debe tener al menos 3 caracteres.",
                    false
                );

                formularioValido = false;

            }


            // =====================================
            // VALIDAR CORREO
            // =====================================

            const formatoCorreo =
                /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


            if (
                !formatoCorreo.test(
                    valorCorreo
                )
            ) {

                mostrarMensaje(
                    correo,
                    "Ingresa un correo electrónico válido.",
                    false
                );

                formularioValido = false;

            }


            // =====================================
            // VALIDAR TELÉFONO
            // =====================================

            if (
                !/^[0-9]+$/.test(
                    valorTelefono
                ) ||
                valorTelefono.length < 8
            ) {

                mostrarMensaje(
                    telefono,
                    "Ingresa un teléfono válido de al menos 8 dígitos.",
                    false
                );

                formularioValido = false;

            }


            // =====================================
            // VALIDAR PAGO
            // =====================================

            if (
                pago.value === ""
            ) {

                mostrarMensaje(
                    pago,
                    "Selecciona una forma de pago.",
                    false
                );

                formularioValido = false;

            }


            // =====================================
            // SI HAY ERRORES
            // =====================================

            if (!formularioValido) {

                alert(
                    "Por favor, corrige los errores antes de continuar."
                );

                return;

            }


            // =====================================
            // OBTENER VEHÍCULO
            // =====================================

            const elementoVehiculo =
                formulario.closest(".compra")
                    .querySelector(
                        ".auto-compra strong"
                    );


            const elementoPrecio =
                formulario.closest(".compra")
                    .querySelector(
                        ".auto-compra b"
                    );


            const vehiculo =
                elementoVehiculo
                    ? elementoVehiculo.textContent.trim()
                    : "";


            const precio =
                elementoPrecio
                    ? elementoPrecio.textContent.trim()
                    : "";


            // =====================================
            // OBTENER FORMA DE PAGO
            // =====================================

            const formaPago =
                obtenerNombrePago(
                    pago.value
                );


            // =====================================
            // MOSTRAR EN EL RESUMEN
            // =====================================

            const resumenVehiculo =
                document.getElementById(
                    "resumen-vehiculo"
                );

            const resumenPrecio =
                document.getElementById(
                    "resumen-precio"
                );

            const resumenNombre =
                document.getElementById(
                    "resumen-nombre"
                );

            const resumenCorreo =
                document.getElementById(
                    "resumen-correo"
                );

            const resumenTelefono =
                document.getElementById(
                    "resumen-telefono"
                );

            const resumenPago =
                document.getElementById(
                    "resumen-pago"
                );


            if (resumenVehiculo) {

                resumenVehiculo.textContent =
                    vehiculo;

            }


            if (resumenPrecio) {

                resumenPrecio.textContent =
                    precio;

            }


            if (resumenNombre) {

                resumenNombre.textContent =
                    valorNombre;

            }


            if (resumenCorreo) {

                resumenCorreo.textContent =
                    valorCorreo;

            }


            if (resumenTelefono) {

                resumenTelefono.textContent =
                    valorTelefono;

            }


            if (resumenPago) {

                resumenPago.textContent =
                    formaPago;

            }


            // =====================================
            // GENERAR NÚMERO DE OPERACIÓN
            // =====================================

            const numeroOperacion =
                "AZ-" +
                Date.now()
                    .toString()
                    .slice(-6);


            // =====================================
            // GUARDAR COMPRA
            // =====================================

            const compra =
                {
                    vehiculo: vehiculo,
                    precio: precio,
                    nombre: valorNombre,
                    correo: valorCorreo,
                    telefono: valorTelefono,
                    pago: formaPago,
                    operacion: numeroOperacion
                };


            localStorage.setItem(
                "compraAUTOZONE",
                JSON.stringify(compra)
            );


            // =====================================
            // LIMPIAR FORMULARIO
            // =====================================

            formulario.reset();


            // =====================================
            // MOSTRAR RESUMEN
            // =====================================

            window.location.hash =
                "resumen-compra";

        }

    );

});


// =================================================
// 5.1 CONFIRMAR COMPRA
// =================================================

const botonConfirmarResumen =
    document.querySelector(
        '#resumen-compra .boton-confirmar-compra'
    );


if (botonConfirmarResumen) {

    botonConfirmarResumen.addEventListener(
        "click",
        function (evento) {

            evento.preventDefault();


            // =====================================
            // RECUPERAR COMPRA
            // =====================================

            const compraGuardada =
                JSON.parse(
                    localStorage.getItem(
                        "compraAUTOZONE"
                    )
                );


            if (!compraGuardada) {

                alert(
                    "No se encontró información de la compra."
                );

                return;

            }


            // =====================================
            // ELEMENTOS DE CONFIRMACIÓN
            // =====================================

            const confirmacionNombre =
                document.getElementById(
                    "confirmacion-nombre"
                );

            const confirmacionVehiculo =
                document.getElementById(
                    "confirmacion-vehiculo"
                );

            const confirmacionPrecio =
                document.getElementById(
                    "confirmacion-precio"
                );

            const confirmacionPago =
                document.getElementById(
                    "confirmacion-pago"
                );

            const numeroOperacion =
                document.getElementById(
                    "numero-operacion"
                );


            // =====================================
            // MOSTRAR DATOS
            // =====================================

            if (confirmacionNombre) {

                confirmacionNombre.textContent =
                    compraGuardada.nombre;

            }


            if (confirmacionVehiculo) {

                confirmacionVehiculo.textContent =
                    compraGuardada.vehiculo;

            }


            if (confirmacionPrecio) {

                confirmacionPrecio.textContent =
                    compraGuardada.precio;

            }


            if (confirmacionPago) {

                confirmacionPago.textContent =
                    compraGuardada.pago;

            }


            if (numeroOperacion) {

                numeroOperacion.textContent =
                    compraGuardada.operacion;

            }


            // =====================================
            // ELIMINAR VEHÍCULO DEL CARRITO
            // =====================================

            const indice =
                carrito.findIndex(
                    function (auto) {

                        return (
                            auto.vehiculo ===
                            compraGuardada.vehiculo
                        );

                    }
                );


            if (indice !== -1) {

                carrito.splice(
                    indice,
                    1
                );


                localStorage.setItem(
                    "carritoAUTOZONE",
                    JSON.stringify(carrito)
                );


                actualizarContadorCarrito();

                mostrarCarrito();

            }


            // =====================================
            // MOSTRAR CONFIRMACIÓN
            // =====================================

            window.location.hash =
                "confirmacion-compra";

        }
    );

}


// =================================================
// 5.2 CONTINUAR DESDE EL CARRITO
// =================================================

const botonContinuarCompra =
    document.getElementById(
        "boton-continuar-compra"
    );


if (botonContinuarCompra) {

    botonContinuarCompra.addEventListener(
        "click",
        function (evento) {

            evento.preventDefault();


            // =====================================
            // COMPROBAR CARRITO
            // =====================================

            if (carrito.length === 0) {

                alert(
                    "Tu carrito está vacío."
                );

                return;

            }


            // =====================================
            // TOMAR EL PRIMER VEHÍCULO
            // =====================================

            const auto =
                carrito[0];


            // =====================================
            // IDENTIFICAR EL FORMULARIO
            // =====================================

            let destino = "";

            // Normalizamos el nombre para evitar problemas por
            // espacios, mayúsculas/minúsculas o datos antiguos.
            const nombreVehiculo =
                String(auto.vehiculo || auto.nombre || "")
                    .trim()
                    .toLowerCase();

            if (nombreVehiculo === "bmw serie 3") {

                destino = "comprar-bmw";

            }
            else if (nombreVehiculo === "audi a4") {

                destino = "comprar-audi";

            }
            else if (nombreVehiculo === "mercedes-benz clase c" ||
                     nombreVehiculo === "mercedes benz clase c") {

                destino = "comprar-mercedes";

            }
            else if (nombreVehiculo === "toyota corolla") {

                destino = "comprar-toyota";

            }


            // =====================================
            // SI NO SE ENCUENTRA
            // =====================================

            if (destino === "") {

                alert(
                    "No se pudo identificar el vehículo."
                );

                return;

            }


            // =====================================
            // IR AL FORMULARIO
            // =====================================

            window.location.hash =
                destino;

        }
    );

}



    // =================================================
    // 7. FUNCIÓN FORMA DE PAGO
    // =================================================

    function obtenerNombrePago(pago) {

        if (pago === "contado") {

            return "Pago al contado";

        }


        if (pago === "credito") {

            return "Crédito automotriz";

        }


        if (pago === "financiamiento") {

            return "Financiamiento";

        }


        return "No especificado";

    }


    // =================================================
    // 8. MOSTRAR CARRITO AL ABRIR LA PÁGINA
    // =================================================

    // Ejecutamos al final porque ahora la variable
    // carrito ya fue creada correctamente.

    mostrarCarrito();





});
